#ifndef LAB04_SQLITE_H
#define LAB04_SQLITE_H

#define DB_FILE "mydb.db"

void sqlite_get_data();
void sqlite_update(int compid, char *compname, float price);

#endif
