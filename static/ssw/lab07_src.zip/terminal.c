#include "terminal.h"

uint16_t *terminal_buffer;
size_t terminal_row;
size_t terminal_column;
uint8_t terminal_colour;

static inline uint8_t vga_entry_colour(enum vga_colour foreground, enum vga_colour background)
{
    return foreground | (background << 4);
}

static inline uint16_t vga_entry(unsigned char c, uint8_t colour)
{
    return (uint16_t)c | ((uint16_t)colour << 8);
}

void terminal_putcharat(char c, uint16_t colour, size_t x, size_t y)
{
    const size_t index = y * VGA_WIDTH + x;
    terminal_buffer[index] = vga_entry(c, colour);
}

void terminal_initialize()
{
    terminal_row = 0;
    terminal_column = 0;
    terminal_colour = vga_entry_colour(VGA_COLOUR_WHITE, VGA_COLOUR_BLUE);
    terminal_buffer = (uint16_t *)0xB8000;
    size_t x, y;
    for (y = 0; y < VGA_HEIGHT; y++)
    {
        for (x = 0; x < VGA_WIDTH; x++)
        {
            const size_t index = y * VGA_WIDTH + x;
            terminal_buffer[index] = vga_entry(' ', terminal_colour);
        }
    }
}

void terminal_scroll_up()
{
    unsigned long int i;
    for (i = 0; i < (VGA_WIDTH * VGA_HEIGHT - 80); i++)
        terminal_buffer[i] = terminal_buffer[i + 80];
    for (i = 0; i < VGA_WIDTH; i++)
        terminal_buffer[(VGA_HEIGHT - 1) * VGA_WIDTH + i] = vga_entry(' ', terminal_colour);
}

void terminal_putchar(char c)
{
    if (terminal_column == VGA_WIDTH || c == '\n')
    {
        terminal_column = 0;
        if (terminal_row == VGA_HEIGHT - 1)
            terminal_scroll_up();
        else
            terminal_row++;
    }
    if (c == '\n')
        return;
    terminal_putcharat(c, terminal_colour, terminal_column++, terminal_row);
}

void terminal_write(const char *data, size_t size)
{
    size_t i;
    for (i = 0; i < size; i++)
        terminal_putchar(data[i]);
}

void terminal_writestring(const char *data)
{
    terminal_write(data, strlen(data));
}

void terminal_writestring_colour(const char *data, enum vga_colour fg, enum vga_colour bg)
{
    uint8_t oldcolour = terminal_colour;
    terminal_colour = vga_entry_colour(fg, bg);
    terminal_writestring(data);
    terminal_colour = oldcolour;
}

void terminal_writeint(unsigned long n)
// {
//     YOUR CODE HERE
// }

void terminal_goto(size_t x, size_t y)
// {
//     YOUR CODE HERE
// }

void terminal_setcolour(enum vga_colour foreground, enum vga_colour background)
{
    terminal_colour = vga_entry_colour(foreground, background);
}
