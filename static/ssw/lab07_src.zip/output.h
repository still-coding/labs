#ifndef OUTPUT_H
#define OUTPUT_H

#include "terminal.h"
#include "rand.h"

#define PEKA0 "                       ,----------------,              ,---------,\n"
#define PEKA1 "                  ,-----------------------,          ,\"        ,\"|\n"
#define PEKA2 "                ,\"                      ,\"|        ,\"        ,\"  |\n"
#define PEKA3 "               +-----------------------+  |      ,\"        ,\"    |\n"
#define PEKA4 "               |  .-----------------.  |  |     +---------+      |\n"
#define PEKA5 "               |  |                 |  |  |     | -==----'|      |\n"
#define PEKA6 "               |  |  hello, user    |  |  |     |         |      |\n"
#define PEKA7 "               |  |                 |  |  |/----|`---=    |      |\n"
#define PEKA8 "               |  |                 |  |  |   ,/|==== ooo |      ;\n"
#define PEKA9 "               |  |                 |  |  |  // |(((( [33]|    ,\"\n"
#define PEKA10 "               |  `-----------------'  |,\" .;'| |((((     |  ,\"\n"
#define PEKA11 "               +-----------------------+  ;;  | |         |,\"\n"
#define PEKA12 "                  /_)______________(_/  //'   | +---------+\n"
#define PEKA13 "             ___________________________/___  `,\n"
#define PEKA14 "            /  oooooooooooooooo  .o.  oooo /,   \\,\"-----------\n"
#define PEKA15 "           / ==ooooooooooooooo==.o.  ooo= //   ,`\\--{)B     ,\"\n"
#define PEKA16 "          /_==__==========__==_ooo__ooo=_/'   /___________,\"\n"
#define PEKA17 "          `-----------------------------'\n"
#define PEKAS {PEKA0,PEKA1,PEKA2,PEKA3,PEKA4,PEKA5,PEKA6,PEKA7,PEKA8,PEKA9,PEKA10,PEKA11,PEKA12,PEKA13,PEKA14,PEKA15,PEKA16,PEKA17}
#define PEKA_LINES 18

#define SPACES "                 "

extern void delay(int);

void print_peka(void);
void fill(uint8_t, int);
void matrix(void);
void glitch(unsigned char);
void cursor(unsigned char);

#endif
