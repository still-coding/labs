#include "rand.h"

unsigned long next = 1;

void srand(unsigned int seed)
// {
//     YOUR CODE HERE
// }

int rand()
// {
//     YOUR CODE HERE
// }
