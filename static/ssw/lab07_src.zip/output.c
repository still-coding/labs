#include "output.h"

static const char *ch = "1234567890qwertyuiopasdfghjklzxcvbnm,./';[]!@#$%^&*()-=_+";
static size_t l;

void print_peka()
{
    const char *pekas[PEKA_LINES] = PEKAS;
    unsigned char i;
    for (i = 0; i < PEKA_LINES; i++)
    {
        terminal_writestring(pekas[i]);
    }
}

void fill(uint8_t c, int d)
{
    size_t r = 5;
    terminal_goto(19, r++);
    terminal_writestring_colour(SPACES, VGA_COLOUR_LIGHT_GREEN, c);
    terminal_goto(19, r++);
    terminal_writestring_colour(SPACES, VGA_COLOUR_LIGHT_GREEN, c);
    terminal_goto(19, r++);
    terminal_writestring_colour(SPACES, VGA_COLOUR_LIGHT_GREEN, c);
    terminal_goto(19, r++);
    terminal_writestring_colour(SPACES, VGA_COLOUR_LIGHT_GREEN, c);
    terminal_goto(19, r++);
    terminal_writestring_colour(SPACES, VGA_COLOUR_LIGHT_GREEN, c);
    terminal_goto(19, r++);
    delay(d);
}

void matrix()
{
    l = strlen(ch);
    const unsigned int flipsPerLine = 5;
    unsigned int i;
    char switches[VGA_WIDTH];
    int x;
    for (;;)
    {
        for (i = 0; i < VGA_WIDTH; i += 2)
        {
            if (switches[i])
            {
                terminal_putchar(ch[rand() % l]);
                terminal_putchar(' ');
            }
            else
                terminal_writestring("  ");
        }
        for (i = 0; i != flipsPerLine; ++i)
        {
            x = rand() % VGA_WIDTH;
            switches[x] = !switches[x];
        }
        terminal_putchar('\n');
        delay(50);
    }
}

void glitch(unsigned char len)
{
    l = strlen(ch);
    unsigned char i;
    for (i = 0; i < len; i++)
    {
        terminal_setcolour(rand() % 16, VGA_COLOUR_BLACK);
        terminal_putchar(ch[rand() % l]);
        delay(rand() % 100);
    }
}

void cursor(unsigned char times)
{
    unsigned char i;
    for (i = 0; i < times; i++)
    {
        terminal_goto(35, 7);
        terminal_putchar('_');
        delay(400);
        terminal_goto(35, 7);
        terminal_putchar(' ');
        delay(400);
    }
}
