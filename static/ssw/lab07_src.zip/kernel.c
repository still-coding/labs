#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include "output.h"
#include "rand.h"
#include "terminal.h"

extern uint32_t _timestamp_edx();
extern uint32_t _timestamp_eax();

size_t strlen(const char *str)
{
    size_t len = 0;
    while (str[len])
        len++;
    return len;
}

void delay(int t)
{
    volatile int i, j;
    for (i = 0; i < t; i++)
        for (j = 0; j < 250000; j++)
            __asm__("NOP");
}

void kernel_main()
{
    srand(_timestamp_eax());

    terminal_initialize();

    // TODO: write your own terminal graphics here and in output.c/.h files

    // print_peka();
    //
    // delay(2000);
    //
    // unsigned char i;
    // for (i = 0; i < 10; i++)
    // {
    //     fill(rand() % 16, rand() % 200);
    // }
    // fill(VGA_COLOUR_BLACK, 0);
    //
    // delay(2000);
    //
    // terminal_goto(20, 7);
    // glitch(15);
    // terminal_goto(20, 7);
    // terminal_writestring_colour("Wake up, Neo...", VGA_COLOUR_LIGHT_GREEN, VGA_COLOUR_BLACK);
    // terminal_setcolour(VGA_COLOUR_WHITE, VGA_COLOUR_BLACK);
    //
    // cursor(15);
    // terminal_goto(0, 0);
    // terminal_setcolour(VGA_COLOUR_LIGHT_GREEN, VGA_COLOUR_BLACK);
    // matrix();
}
