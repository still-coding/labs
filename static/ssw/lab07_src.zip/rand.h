#ifndef RAND_H
#define RAND_H

#define RAND_MAX 32767

void srand(unsigned int);
int rand(void);
#endif
